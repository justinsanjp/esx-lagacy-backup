Locales['sv'] = {
    ['used_food'] = 'Du har ätit 1x %s',
    ['used_drink'] = 'Du har druckit 1x %s',
    ['got_healed'] = 'Du har blivit läkt.'
  }
