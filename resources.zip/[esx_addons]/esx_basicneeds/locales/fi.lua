Locales['fi'] = {
  ['used_bread'] = 'sinä söit 1x leipä',
  ['used_water'] = 'sinä joit 1x vesi',
}