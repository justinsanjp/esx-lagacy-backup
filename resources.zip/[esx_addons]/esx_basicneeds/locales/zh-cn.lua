Locales['zh-cn'] = {
  ['used_food'] = '已食用了1x %s',
  ['used_drink'] = '已饮用了1x %s',
  ['got_healed'] = '已重置饥饿+饥渴双值.'
}
