Locales['fi'] = {
  ['valid_this_purchase'] = 'Vahvista tämä ostos?',
  ['yes'] = 'Kyllä',
  ['no'] = 'Ei',
  ['not_enough_money'] = 'Sinulla ei ole tarpeeksi rahaa',
  ['press_menu'] = 'Paina [E] avataksesi vaatekauppa',
  ['clothes'] = 'Vaatekauppa',
  ['you_paid'] = 'Sinä maksoit $%s',
  ['save_in_dressing'] = 'Haluatko antaa asulle nimen?',
  ['name_outfit'] = 'Asun nimi',
  ['saved_outfit'] = 'Asu on tallennettu!',
}
