Locales['it'] = {
  ['valid_this_purchase'] = 'Convalidare questo acquisto?',
  ['yes'] = 'Si',
  ['no'] = 'No',
  ['not_enough_money'] = 'Non hai abbastanza soldi',
  ['press_menu'] = 'Premere [E] per accedere al menu',
  ['clothes'] = 'Vestiario',
  ['you_paid'] = 'Hai pagato €%s',
  ['save_in_dressing'] = 'Vuoi dare un nome al tuo guardaroba?',
  ['name_outfit'] = 'nome dell\' outfit?',
  ['saved_outfit'] = 'L abito è stato salvato!',
}
