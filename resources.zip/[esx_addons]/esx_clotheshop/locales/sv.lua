Locales['sv'] = {
    ['valid_this_purchase'] = 'Vill du köpa detta?',
    ['yes'] = 'Ja',
    ['no'] = 'Nej',
    ['not_enough_money'] = 'Du har inte tillräckligt med pengar',
    ['press_menu'] = 'Tryck [E] för att öppna klädaffären.',
    ['clothes'] = 'Klädaffär',
    ['you_paid'] = 'Du betalade %skr',
    ['save_in_dressing'] = 'Vill du spara denna outfit till din fastighet?',
    ['name_outfit'] = 'Outfit namn',
    ['saved_outfit'] = 'Outfiten är sparad!',
  }
