Locales['de'] = {
  ['valid_this_purchase'] = 'Kauf bestätigen?',
  ['yes'] = 'Ja',
  ['no'] = 'Nein',
  ['not_enough_money'] = 'Du hast nicht genügend Geld',
  ['press_menu'] = 'Drücke [E] um auf den Kleidungsladen zuzugreifen.',
  ['clothes'] = 'Kleidungsladen',
  ['you_paid'] = 'Du zahlst %s€',
  ['save_in_dressing'] = 'Willst du dieses Outfit in deiner Umkleide speichern?',
  ['name_outfit'] = 'Bennene dein Outfit',
  ['saved_outfit'] = 'Das Outfit wurde gespeichert!',
}
