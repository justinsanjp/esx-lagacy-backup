Locales['sl'] = {
  ['valid_this_purchase'] = 'Potrdite nakup',
  ['yes'] = 'Da',
  ['no'] = 'Ne',
  ['not_enough_money'] = 'Vi nimate dovolj denarja!',
  ['press_menu'] = 'Pritisnite [E] da odprete Trgovino z Oblačili.',
  ['clothes'] = 'Trgovina Oblačil',
  ['you_paid'] = 'Vi ste plačali $%s',
  ['save_in_dressing'] = 'Bi radi shranili svojo obleko v omaro?',
  ['name_outfit'] = 'Izberite ime za vaš Outfit',
  ['saved_outfit'] = 'Outfit je bil shranjen!',
}