Locales['cs'] = {
  ['invoices'] = 'faktury',
  ['invoices_item'] = '$%s',
  ['received_invoice'] = 'právě jsi ~r~obdrzel fakturu',
  ['paid_invoice'] = 'zaplatil jsi fakturu za ~r~$%s',
  ['no_invoices'] = 'momentalne nemas zadnou fatkuru k zaplaceni',
  ['received_payment'] = 'obdržel jsi platbu za ~r~$%s',
  ['player_not_online'] = 'hráč není přihlášen',
  ['no_money'] = 'nemáš dostatek peněz na zaplacení této faktury',
  ['target_no_money'] = 'hráč ~r~nemá dostatek peněz na zaplacení faktury!',
  ['keymap_showbills'] = 'otevrit menu faktur',
}
