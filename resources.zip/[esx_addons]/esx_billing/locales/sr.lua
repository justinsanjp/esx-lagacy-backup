Locales['sr'] = {
  ['invoices'] = 'Računi',
  ['invoices_item'] = '$%s',
  ['received_invoice'] = 'Vi ste ~r~dobili novi račun',
  ['paid_invoice'] = 'Platili ste račun od ~r~$%s',
  ['no_invoices'] = 'Nemate računa za plaćanje trenutno',
  ['received_payment'] = 'Primili ste uplatu u iznosu od ~r~$%s',
  ['player_not_online'] = 'Osoba nije tu',
  ['no_money'] = 'Nemate dovoljno novca da platite račun',
  ['target_no_money'] = 'Osoba ~r~nema dovoljno novca da plati račun!',
  ['keymap_showbills'] = 'Otvori Račune',
}
