Locales['it'] = {
  ['invoices'] = 'fatture',
  ['invoices_item'] = '$%s',
  ['received_invoice'] = 'hai appena ~r~ricevuto~s~ una fattura',
  ['paid_invoice'] = 'hai ~g~pagato~s~ una fattura di ~r~$%s~s~',
  ['no_invoices'] = 'non hai nessuna fattura da pagare',
  ['received_payment'] = 'hai ~g~ricevuto~s~ il pagamento di ~r~$%s~s~',
  ['player_not_online'] = 'il giocatore non ha effettuato l\'accesso',
  ['no_money'] = 'non hai abbastanza soldi per pagare questa fattura',
  ['target_no_money'] = 'il giocatore ~r~non ha~s~ abbastanza soldi per pagare la fattura!',
  ['keymap_showbills'] = 'apri il menu delle fatture',
}
