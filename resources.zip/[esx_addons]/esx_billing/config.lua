Config = {}
Config.Locale = GetConvar('esx:locale', 'en')
