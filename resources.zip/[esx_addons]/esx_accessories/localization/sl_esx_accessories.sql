INSERT INTO `datastore` (name, label, shared) VALUES
	('user_ears', 'Usesa', 0),
	('user_glasses', 'Ocala', 0),
	('user_helmet', 'Klobuk', 0),
	('user_mask', 'Maska', 0)
;
