INSERT INTO `datastore` (name, label, shared) VALUES
	('user_ears', 'Orecchini', 0),
	('user_glasses', 'Occhiali', 0),
	('user_helmet', 'Caschi', 0),
	('user_mask', 'Maschere', 0)
;
