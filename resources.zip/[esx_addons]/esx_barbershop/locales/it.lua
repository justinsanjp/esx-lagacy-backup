Locales['it'] = {
  ['valid_purchase'] = 'confermare l\'acquisto?',
  ['yes'] = 'si',
  ['no'] = 'no',
  ['not_enough_money'] = 'non hai abbastanza soldi',
  ['press_access'] = 'premi [E] per usufruire del barbiere.',
  ['barber_blip'] = 'barbiere',
  ['you_paid'] = 'hai pagato $%s',
}
