Locales['tr'] = {
  ['valid_purchase'] = 'Değişikliği onaylıyor musun?',
  ['yes'] = 'Evet',
  ['no'] = 'Hayır',
  ['not_enough_money'] = 'Yeterli paran yok',
  ['press_access'] = 'Kuaför Salonuna girmek için ~b~[E]~s~ tuşuna bas.',
  ['barber_blip'] = 'Kuaför Salonu',
  ['you_paid'] = 'Ödeme yaptınız: $%s',
}
