Locales['sr'] = {
  ['valid_purchase'] = 'Potvrdite kupovinu?',
  ['yes'] = 'Da',
  ['no'] = 'Ne',
  ['not_enough_money'] = 'Nemate dovoljno novca',
  ['press_access'] = 'Pritisnite [E] da pristupite Frizerskom Salonu.',
  ['barber_blip'] = 'Frizerski Salon',
  ['you_paid'] = 'Platili ste $%s',
}
