Locales['de'] = {
  ['valid_purchase'] = 'Einkauf bestätigen?',
  ['yes'] = 'Ja',
  ['no'] = 'Nein',
  ['not_enough_money'] = 'Du hast nicht genug Geld',
  ['press_access'] = 'Drücke ~INPUT_CONTEXT~ um das Menü zu öffnen',
  ['barber_blip'] = 'Friseur',
  ['you_paid'] = 'Du bezahlst %s€',
}
