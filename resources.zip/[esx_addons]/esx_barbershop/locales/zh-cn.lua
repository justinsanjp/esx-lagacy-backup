Locales['zh-cn'] = {
  ['valid_purchase'] = '确认当前改变?',
  ['yes'] = '确认',
  ['no'] = '取消',
  ['not_enough_money'] = '暂无足够现金!',
  ['press_access'] = '键下 [E] 访问理发店.',
  ['barber_blip'] = '理发店',
  ['you_paid'] = '已成功支付 $%s',
}
