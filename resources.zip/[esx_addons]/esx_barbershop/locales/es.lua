Locales['es'] = {
  ['valid_purchase'] = '¿Desea realizar esta compra?',
  ['yes'] = 'Si',
  ['no'] = 'No',
  ['not_enough_money'] = 'No tienes suficente dinero',
  ['press_access'] = 'Presiona [E] para acceder a la barberia',
  ['barber_blip'] = 'Barbero',
  ['you_paid'] = 'Has pagado $%s',
}
