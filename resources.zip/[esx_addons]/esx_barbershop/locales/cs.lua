Locales['cs'] = {
  ['valid_purchase'] = 'potvrdit nakup?',
  ['yes'] = 'ano',
  ['no'] = 'ne',
  ['not_enough_money'] = 'nemas dostatek penez',
  ['press_access'] = 'stiskni [E] pro pristup k Holici.',
  ['barber_blip'] = 'Holic',
  ['you_paid'] = 'zaplatil jsi $%s',
}
