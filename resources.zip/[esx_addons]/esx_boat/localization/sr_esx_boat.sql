INSERT INTO `licenses` (`type`, `label`) VALUES
	('boat', 'Dozvola za Brod')
;
