fx_version 'adamant'

game 'gta5'
author 'ESX-Framework'
description 'Allows resources to Run tasks at specific intervals.'
lua54 'yes'
version '1.11.4'

server_script 'server/main.lua'
