Locales["pt"] = {
    ["skin_menu"] = "Menu de Skin",
    ["use_rotate_view"] = "Usa Q e E para rodar a câmara.",
    ["skin"] = "alterar skin",
    ["saveskin"] = "salvar a skin num ficheiro",
}
