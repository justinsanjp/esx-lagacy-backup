Locales["it"] = {
    ["skin_menu"] = "Menu Skin",
    ["use_rotate_view"] = "usa Q e E per ruotare la visuale.",
    ["skin"] = "cambia skin",
    ["saveskin"] = "salvare la skin",
}
