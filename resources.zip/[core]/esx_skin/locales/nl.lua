Locales["nl"] = {
    ["skin_menu"] = "Kleding Menu",
    ["use_rotate_view"] = "gebruik Q en E om de camera te draaien.",
    ["skin"] = "verander outfit",
    ["saveskin"] = "sla outfit op in je kledingkast.",
}
