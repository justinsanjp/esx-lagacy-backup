Locales["sl"] = {
    ["skin_menu"] = "Oblacilni menu.",
    ["use_rotate_view"] = "Pritisni Q in E da se obracas s pogledom.",
    ["skin"] = "Zamenjaj Skin.",
    ["saveskin"] = "Shrani skin.",
}
