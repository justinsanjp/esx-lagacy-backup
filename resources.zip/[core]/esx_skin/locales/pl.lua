Locales["pl"] = {
    ["skin_menu"] = "menu wyglądu",
    ["use_rotate_view"] = "użyj Q i E aby obrócić ekran.",
    ["skin"] = "zmień wygląd",
    ["saveskin"] = "zapisz wygląd do pliku",
}
