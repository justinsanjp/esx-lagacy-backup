Locales["sr"] = {
    ["skin_menu"] = "Skin Meni",
    ["use_rotate_view"] = "koristi Q i E da rotiras kameru.",
    ["skin"] = "promeni skin",
    ["saveskin"] = "sacuvaj skin u file",
}
