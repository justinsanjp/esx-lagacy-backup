Locales["de"] = {
    ["skin_menu"] = "Skin Menü",
    ["use_rotate_view"] = "Drücke Q oder E um deine Ansicht zu ändern.",
    ["skin"] = "Aussehen ändern",
    ["saveskin"] = "Aussehen abspeichern",
  }
