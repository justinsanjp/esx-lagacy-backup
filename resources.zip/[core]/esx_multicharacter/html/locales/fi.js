const translate = new Object();

translate.name = "Nimi";
translate.job = "Työ";
translate.bank = "Pankki";
translate.money = "Käteinen";
translate.gender = "Sukupuoli";
translate.dob = "Syntymäaika";
