function lib.getLocaleKey() return GetConvar('ox:locale', 'en') end
